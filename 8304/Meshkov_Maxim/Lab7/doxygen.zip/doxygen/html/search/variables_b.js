var searchData=
[
  ['selectioncolor_661',['selectionColor',['../GuiConstants_8hpp.html#abf81f9a1e705e582b3f4fa8798db82e8',1,'GuiConstants.hpp']]],
  ['standardmargin_662',['standardMargin',['../GuiConstants_8hpp.html#ab622b48932ba6d1cec49264aedeb6f5e',1,'GuiConstants.hpp']]],
  ['stonecolor_663',['stoneColor',['../GuiConstants_8hpp.html#ab8101341e32c9e2eea9910d70a39c14c',1,'GuiConstants.hpp']]],
  ['stoneprobability_664',['stoneProbability',['../classGameStartRule.html#aecdda231bb461506d96f773c133a9ca5',1,'GameStartRule']]],
  ['subtlefontcolor_665',['subtleFontColor',['../GuiConstants_8hpp.html#a900b194179f7e103a3fafd2033bcdb11',1,'GuiConstants.hpp']]]
];

var searchData=
[
  ['backgroundcolor_587',['backgroundColor',['../GuiConstants_8hpp.html#af549f49aa2895dbf977d82e4c505e23d',1,'GuiConstants.hpp']]],
  ['bases_588',['bases',['../classGameMemento.html#a9bd008dec9af8db06950c5faca1d97f6',1,'GameMemento']]],
  ['bordercolor_589',['borderColor',['../GuiConstants_8hpp.html#ac7c762fe768dbbf5a6fdbefe890b64fa',1,'GuiConstants.hpp']]],
  ['borderwidth_590',['borderWidth',['../GuiConstants_8hpp.html#a8de489da52c60abccad4c80aaab86c39',1,'GuiConstants.hpp']]],
  ['buttonfontsize_591',['buttonFontSize',['../GuiConstants_8hpp.html#ae66953e0fb56df505e684d007bd1620a',1,'GuiConstants.hpp']]]
];

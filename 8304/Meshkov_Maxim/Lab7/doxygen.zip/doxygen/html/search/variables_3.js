var searchData=
[
  ['fieldheight_597',['fieldHeight',['../classGameMemento.html#a89dbc51ce98ef02a11675774fab84cf5',1,'GameMemento']]],
  ['fieldwidth_598',['fieldWidth',['../classGameMemento.html#a5c288a37fd26b74e4d2e0816b5cc2dd6',1,'GameMemento']]]
];

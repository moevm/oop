var searchData=
[
  ['applyto_455',['applyTo',['../classMedicineThing.html#ad6aed758aa31920efdb9556a3c8ad069',1,'MedicineThing::applyTo()'],['../classMicroMedicineThing.html#a8e06bfe31c31de3337814af0ba121c95',1,'MicroMedicineThing::applyTo()'],['../classPowerfulMedicineThing.html#a81f8747bdb83fabfc3855c40fabe1cfc',1,'PowerfulMedicineThing::applyTo()'],['../classSmallMedicineThing.html#a8a5d36dae9ad893bc0d0f145f48ff548',1,'SmallMedicineThing::applyTo()'],['../classThing.html#aa49ad5df4dbafe776948cd171b67f49a',1,'Thing::applyTo()']]],
  ['archerunit_456',['ArcherUnit',['../classArcherUnit.html#a8608203079a9c0992d30dca67be62b92',1,'ArcherUnit']]],
  ['at_457',['at',['../classTwoDimensionalArray.html#abdf248cd5cb7e681fcce1048f2e79f3a',1,'TwoDimensionalArray::at(int row, int col)'],['../classTwoDimensionalArray.html#a37f02fc2e546d18256d8500642025543',1,'TwoDimensionalArray::at(int row, int col) const']]],
  ['attack_458',['attack',['../classGame.html#a31d09268e37af8fc03ef5b31e8361286',1,'Game::attack()'],['../classGameInterface.html#a26006488b7aac5e0bd910ac9a55d398f',1,'GameInterface::attack()'],['../classGameProxyWithLogging.html#a332339ae910f740e84b1f8c2cef12972',1,'GameProxyWithLogging::attack()'],['../classBaseUnit.html#a5e009979bf0343e4c9fbf532f9d19ffe',1,'BaseUnit::attack()'],['../classUnit.html#a5f9b8f6ee790089c349587cb518ff156',1,'Unit::attack()']]]
];

var searchData=
[
  ['inlinemargin_604',['inlineMargin',['../GuiConstants_8hpp.html#a63451479f0b15925be301c07d88a823d',1,'GuiConstants.hpp']]],
  ['isiced_605',['isIced',['../structGameMemento_1_1UnitInfo.html#a7956efdf543e6b752634f025feb25f61',1,'GameMemento::UnitInfo']]]
];

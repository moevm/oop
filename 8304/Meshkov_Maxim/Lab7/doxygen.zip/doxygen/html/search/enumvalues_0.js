var searchData=
[
  ['distance_5farcher_681',['DISTANCE_ARCHER',['../classGameMemento.html#aa90997cec8963890d7cf1442e9cf47c2aeb8e43be9bfefb85f435f262443d847c',1,'GameMemento']]]
];

var searchData=
[
  ['powerful_689',['POWERFUL',['../classGameMemento.html#ab84b216fcbb58d2e9dd6c0c949a27201a3717d501a13553f3bd3dcca91ae9a349',1,'GameMemento']]],
  ['powerful_5farcher_690',['POWERFUL_ARCHER',['../classGameMemento.html#aa90997cec8963890d7cf1442e9cf47c2ae9859a4b1454b1a9443efd0260a751d8',1,'GameMemento']]]
];

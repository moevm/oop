var searchData=
[
  ['ice_137',['ice',['../classBaseUnit.html#af06a486be1c92db2e101ab96fd89978d',1,'BaseUnit::ice()'],['../classUnit.html#aa1a579ff0a8ae32467ef402bc409d558',1,'Unit::ice()']]],
  ['ice_5fmage_138',['ICE_MAGE',['../classGameMemento.html#aa90997cec8963890d7cf1442e9cf47c2a6f976ed39fa98e3b0c6e5e506663cbb3',1,'GameMemento']]],
  ['icemageunit_139',['IceMageUnit',['../classIceMageUnit.html',1,'IceMageUnit'],['../classIceMageUnit.html#a8e506249bcce856535462c9ddc72dbff',1,'IceMageUnit::IceMageUnit()']]],
  ['icemageunit_2ehpp_140',['IceMageUnit.hpp',['../IceMageUnit_8hpp.html',1,'']]],
  ['iceswhenattacks_141',['icesWhenAttacks',['../classBaseUnit.html#a4a44b07b0469f22e9a9ca87f4fd305c8',1,'BaseUnit::icesWhenAttacks()'],['../classUnit.html#aa5837b304fb7e2e655d1a9ace1550506',1,'Unit::icesWhenAttacks()']]],
  ['indexingexception_142',['IndexingException',['../classTwoDimensionalArray_1_1IndexingException.html',1,'TwoDimensionalArray&lt; T &gt;::IndexingException'],['../classTwoDimensionalArray_1_1IndexingException.html#aee6d71799fb0418db2d4cb4968b88137',1,'TwoDimensionalArray::IndexingException::IndexingException()']]],
  ['inlinemargin_143',['inlineMargin',['../GuiConstants_8hpp.html#a63451479f0b15925be301c07d88a823d',1,'GuiConstants.hpp']]],
  ['isclicked_144',['isClicked',['../classTextButton.html#af9fa3797c2df0004f89044a2c824bc9b',1,'TextButton']]],
  ['isiced_145',['isIced',['../structGameMemento_1_1UnitInfo.html#a7956efdf543e6b752634f025feb25f61',1,'GameMemento::UnitInfo::isIced()'],['../classBaseUnit.html#ab463b3e52f69aa3825cb0c2ee1e7fd14',1,'BaseUnit::isIced()'],['../classUnit.html#a784eb067b230e4e10c457c7d379e213a',1,'Unit::isIced()']]]
];

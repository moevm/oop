var searchData=
[
  ['player_657',['player',['../structGameMemento_1_1BaseInfo.html#a5a4aba086872f935332bef64c1c955a8',1,'GameMemento::BaseInfo::player()'],['../structGameMemento_1_1UnitInfo.html#aded0aed4df68630d5f96aba36afe8655',1,'GameMemento::UnitInfo::player()']]],
  ['position_658',['position',['../structGameMemento_1_1BaseInfo.html#acfcdddbc3c85972ab18bbba1fca9fb5b',1,'GameMemento::BaseInfo::position()'],['../structGameMemento_1_1ThingInfo.html#aa56fc0bdb8bbb813076804bef65d274b',1,'GameMemento::ThingInfo::position()'],['../structGameMemento_1_1UnitInfo.html#aa4788d043c5211808a4b9eb5e63cbfc2',1,'GameMemento::UnitInfo::position()']]],
  ['possiblemovecolor_659',['possibleMoveColor',['../Gui_8cpp.html#ac9c11fde27955ab586d601ccf9145435',1,'Gui.cpp']]]
];

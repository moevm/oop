var searchData=
[
  ['handleevents_128',['handleEvents',['../classGui.html#a251b2b24ea95b29bfd3eeade460c6bb3',1,'Gui::handleEvents()'],['../classNewUnitSelectionScreen.html#a874071c69e924c8f82251b0a9df7a56f',1,'NewUnitSelectionScreen::handleEvents()'],['../classTextButton.html#a9fea8a594193d592ba032b286ddd4ae4',1,'TextButton::handleEvents()'],['../classUnitInfoScreen.html#ad0f9b5876999a14b4fc38dec31235ad1',1,'UnitInfoScreen::handleEvents()']]],
  ['hasspacetocreate_129',['hasSpaceToCreate',['../classBase.html#a6212ed049e358c6403a272b3250d2333',1,'Base']]],
  ['health_130',['health',['../structGameMemento_1_1BaseInfo.html#aa6f8de3712cd8d3a845d0faa76735c68',1,'GameMemento::BaseInfo::health()'],['../structGameMemento_1_1UnitInfo.html#aa272515cd9ca086ab7682462ea308356',1,'GameMemento::UnitInfo::health()']]],
  ['healthbarwidth_131',['healthBarWidth',['../Gui_8cpp.html#a7892810236b2bbd551ee6073c14b64cc',1,'Gui.cpp']]],
  ['heavy_5fknight_132',['HEAVY_KNIGHT',['../classGameMemento.html#aa90997cec8963890d7cf1442e9cf47c2aa77e8cbe3a589722bc3b38e7a9ba0ecc',1,'GameMemento']]],
  ['heavyknightunit_133',['HeavyKnightUnit',['../classHeavyKnightUnit.html',1,'HeavyKnightUnit'],['../classHeavyKnightUnit.html#ae3121a1267d8f8d1d284e94b3737aac8',1,'HeavyKnightUnit::HeavyKnightUnit()']]],
  ['heavyknightunit_2ehpp_134',['HeavyKnightUnit.hpp',['../HeavyKnightUnit_8hpp.html',1,'']]],
  ['height_135',['height',['../structGuiTools_1_1AreaSize.html#a400a1ae8d668d5cb8d045ec80d462709',1,'GuiTools::AreaSize']]],
  ['hovercolor_136',['hoverColor',['../GuiConstants_8hpp.html#ab149f90034b78f6a5641c68253ecce9a',1,'GuiConstants.hpp']]]
];

var searchData=
[
  ['mageunit_537',['MageUnit',['../classMageUnit.html#acc4fbb663f4a6fef7ac1a47c7b530930',1,'MageUnit']]],
  ['main_538',['main',['../main_8cpp.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main.cpp']]],
  ['modifyhealth_539',['modifyHealth',['../classBase.html#ad98ab4c0d090cc2fde0f97fb4903e605',1,'Base::modifyHealth()'],['../classCreature.html#adb2c5a83034d3a5e9c67beaedbc6614a',1,'Creature::modifyHealth()'],['../classBaseUnit.html#acb7a7f8057b95279b026ae820055c2d5',1,'BaseUnit::modifyHealth()']]],
  ['move_540',['move',['../classGame.html#ad269e043955867903d3d7fb946ebeb3c',1,'Game::move()'],['../classGameInterface.html#af64c3d5f77791af667d228ce370b2831',1,'GameInterface::move()'],['../classGameProxyWithLogging.html#aa7bf66a94a48a2c37353255c00c6dd3f',1,'GameProxyWithLogging::move()']]],
  ['moveismade_541',['moveIsMade',['../classPlayerState.html#a86401e25e5d9230d518ca942608b74e1',1,'PlayerState']]],
  ['moveunit_542',['moveUnit',['../classField.html#a4fd4254dcc0bbe1b16a814d3d1520f2a',1,'Field']]]
];

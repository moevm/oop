var searchData=
[
  ['withtimeloggertoostreamadapter_583',['WithTimeLoggerToOstreamAdapter',['../classWithTimeLoggerToOstreamAdapter.html#a61ad270a402a442f989aa21d75300e49',1,'WithTimeLoggerToOstreamAdapter']]]
];

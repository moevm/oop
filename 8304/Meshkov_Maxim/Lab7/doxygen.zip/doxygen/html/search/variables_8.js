var searchData=
[
  ['normalfontcolor_655',['normalFontColor',['../GuiConstants_8hpp.html#adeed7822d2c9b65e757658e8158a6c74',1,'GuiConstants.hpp']]],
  ['normalfontsize_656',['normalFontSize',['../GuiConstants_8hpp.html#adbda50ff14a84d6cb6a01716352e571b',1,'GuiConstants.hpp']]]
];

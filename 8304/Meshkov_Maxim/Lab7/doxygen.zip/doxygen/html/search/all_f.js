var searchData=
[
  ['reactonunitdeletion_253',['reactOnUnitDeletion',['../classBase.html#a5b6993c1c68b09854f048c198db44b3a',1,'Base']]],
  ['removecreature_254',['removeCreature',['../classField.html#ac0bc0c8910c07b578db0f4d2b1c7a2f1',1,'Field::removeCreature()'],['../structFieldCell.html#a64e0ac06e4f8a9ae7415929c6de109d9',1,'FieldCell::removeCreature()']]],
  ['resetselection_255',['resetSelection',['../classGui.html#aeb2859fd02535375514e4adc52d51e22',1,'Gui']]],
  ['restorefrommemento_256',['restoreFromMemento',['../classGame.html#a6a1ec7bd298f7e103a9b1cac7d3cf69a',1,'Game::restoreFromMemento()'],['../classGameInterface.html#a3da1f1729d7f5bf51cc443eeb5903d37',1,'GameInterface::restoreFromMemento()'],['../classGameProxyWithLogging.html#ac80e8ca73c98f6489b1330d5ef13b0a8',1,'GameProxyWithLogging::restoreFromMemento()']]],
  ['row_257',['row',['../structFieldPosition.html#a2774512da2748c3d6ed45397adbd8454',1,'FieldPosition']]]
];

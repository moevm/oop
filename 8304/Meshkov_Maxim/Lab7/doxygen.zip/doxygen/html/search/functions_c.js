var searchData=
[
  ['needtoclose_543',['needToClose',['../classNewUnitSelectionScreen.html#aa6f78d80094260c706a36a6d49de4024',1,'NewUnitSelectionScreen::needToClose()'],['../classUnitInfoScreen.html#a84a9697245d2aaf0541cf4f47ecc8e49',1,'UnitInfoScreen::needToClose()']]],
  ['newgame_544',['newGame',['../classGui.html#a90ab0bfd104fc1a2d22ff5835b77fbc0',1,'Gui']]],
  ['newunitselectionscreen_545',['NewUnitSelectionScreen',['../classNewUnitSelectionScreen.html#a76abfb705892ab7152182573494c91a2',1,'NewUnitSelectionScreen']]],
  ['notifyaboutdeletionfromfield_546',['notifyAboutDeletionFromField',['../classBaseUnit.html#a42306bea7629efe3add648e118c180a3',1,'BaseUnit::notifyAboutDeletionFromField()'],['../classUnit.html#a5dbc056a4c0bfd5ad70e0d8314c7e949',1,'Unit::notifyAboutDeletionFromField()']]]
];

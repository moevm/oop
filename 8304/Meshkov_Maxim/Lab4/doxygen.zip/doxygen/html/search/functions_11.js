var searchData=
[
  ['twodimensionalarray_467',['TwoDimensionalArray',['../classTwoDimensionalArray.html#a911ba17d4e574bef3bb22a72576cd750',1,'TwoDimensionalArray::TwoDimensionalArray(int width, int height)'],['../classTwoDimensionalArray.html#a4414d39b61a2e99d07fe205cfe8850db',1,'TwoDimensionalArray::TwoDimensionalArray(const TwoDimensionalArray &amp;other)'],['../classTwoDimensionalArray.html#a961b2a89f69d5808825c1adb7e4add54',1,'TwoDimensionalArray::TwoDimensionalArray(TwoDimensionalArray &amp;&amp;other) noexcept']]]
];

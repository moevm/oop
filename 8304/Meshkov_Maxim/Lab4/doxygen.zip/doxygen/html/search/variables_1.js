var searchData=
[
  ['backgroundcolor_478',['backgroundColor',['../GuiConstants_8hpp.html#af549f49aa2895dbf977d82e4c505e23d',1,'GuiConstants.hpp']]],
  ['bordercolor_479',['borderColor',['../GuiConstants_8hpp.html#ac7c762fe768dbbf5a6fdbefe890b64fa',1,'GuiConstants.hpp']]],
  ['borderwidth_480',['borderWidth',['../GuiConstants_8hpp.html#a8de489da52c60abccad4c80aaab86c39',1,'GuiConstants.hpp']]]
];

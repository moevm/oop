var searchData=
[
  ['reactonunitdeletion_204',['reactOnUnitDeletion',['../classBase.html#a5b6993c1c68b09854f048c198db44b3a',1,'Base']]],
  ['removecreature_205',['removeCreature',['../classField.html#ac0bc0c8910c07b578db0f4d2b1c7a2f1',1,'Field::removeCreature()'],['../structFieldCell.html#a64e0ac06e4f8a9ae7415929c6de109d9',1,'FieldCell::removeCreature()']]],
  ['resetselection_206',['resetSelection',['../classGui.html#aeb2859fd02535375514e4adc52d51e22',1,'Gui']]],
  ['row_207',['row',['../structFieldPosition.html#a2774512da2748c3d6ed45397adbd8454',1,'FieldPosition']]]
];

var searchData=
[
  ['selectioncolor_532',['selectionColor',['../GuiConstants_8hpp.html#abf81f9a1e705e582b3f4fa8798db82e8',1,'GuiConstants.hpp']]],
  ['standardmargin_533',['standardMargin',['../GuiConstants_8hpp.html#ab622b48932ba6d1cec49264aedeb6f5e',1,'GuiConstants.hpp']]],
  ['stonecolor_534',['stoneColor',['../GuiConstants_8hpp.html#ab8101341e32c9e2eea9910d70a39c14c',1,'GuiConstants.hpp']]],
  ['stoneprobability_535',['stoneProbability',['../Game_8cpp.html#ad43748093418506067f53e22086a3cf2',1,'Game.cpp']]],
  ['subtlefontcolor_536',['subtleFontColor',['../GuiConstants_8hpp.html#a900b194179f7e103a3fafd2033bcdb11',1,'GuiConstants.hpp']]]
];

var searchData=
[
  ['ice_113',['ice',['../classBaseUnit.html#af06a486be1c92db2e101ab96fd89978d',1,'BaseUnit::ice()'],['../classUnit.html#aa1a579ff0a8ae32467ef402bc409d558',1,'Unit::ice()']]],
  ['icemageunit_114',['IceMageUnit',['../classIceMageUnit.html',1,'IceMageUnit'],['../classIceMageUnit.html#a8e506249bcce856535462c9ddc72dbff',1,'IceMageUnit::IceMageUnit()']]],
  ['icemageunit_2ehpp_115',['IceMageUnit.hpp',['../IceMageUnit_8hpp.html',1,'']]],
  ['iceswhenattacks_116',['icesWhenAttacks',['../classBaseUnit.html#a4a44b07b0469f22e9a9ca87f4fd305c8',1,'BaseUnit::icesWhenAttacks()'],['../classUnit.html#aa5837b304fb7e2e655d1a9ace1550506',1,'Unit::icesWhenAttacks()']]],
  ['isiced_117',['isIced',['../classBaseUnit.html#ab463b3e52f69aa3825cb0c2ee1e7fd14',1,'BaseUnit::isIced()'],['../classUnit.html#a784eb067b230e4e10c457c7d379e213a',1,'Unit::isIced()']]]
];

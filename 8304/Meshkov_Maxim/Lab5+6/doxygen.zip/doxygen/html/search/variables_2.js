var searchData=
[
  ['cellsize_584',['cellSize',['../Gui_8cpp.html#af643985cdd744f53205ed2c8bc710600',1,'cellSize():&#160;Gui.cpp'],['../NewUnitSelectionScreen_8cpp.html#af643985cdd744f53205ed2c8bc710600',1,'cellSize():&#160;NewUnitSelectionScreen.cpp']]],
  ['col_585',['col',['../structFieldPosition.html#ae5fd44ced29218ab4488a6423e4f5fee',1,'FieldPosition']]],
  ['creationability_586',['creationAbility',['../structGameMemento_1_1BaseInfo.html#af774ad01f39f6d5f5e14fa4b8d576c0b',1,'GameMemento::BaseInfo']]],
  ['currentplayer_587',['currentPlayer',['../classGameMemento.html#a6587fa53c5d4e3dc557f8dbae3734144',1,'GameMemento']]],
  ['curtaincolor_588',['curtainColor',['../GuiConstants_8hpp.html#ab8a4cf15743a7b046098f2b04d789e0c',1,'GuiConstants.hpp']]]
];

var searchData=
[
  ['lightweightknightunit_358',['LightweightKnightUnit',['../classLightweightKnightUnit.html',1,'']]],
  ['logger_359',['Logger',['../classLogger.html',1,'']]]
];

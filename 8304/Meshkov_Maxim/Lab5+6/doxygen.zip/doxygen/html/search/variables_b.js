var searchData=
[
  ['selectioncolor_653',['selectionColor',['../GuiConstants_8hpp.html#abf81f9a1e705e582b3f4fa8798db82e8',1,'GuiConstants.hpp']]],
  ['standardmargin_654',['standardMargin',['../GuiConstants_8hpp.html#ab622b48932ba6d1cec49264aedeb6f5e',1,'GuiConstants.hpp']]],
  ['stonecolor_655',['stoneColor',['../GuiConstants_8hpp.html#ab8101341e32c9e2eea9910d70a39c14c',1,'GuiConstants.hpp']]],
  ['stoneprobability_656',['stoneProbability',['../classGameStartRule.html#aecdda231bb461506d96f773c133a9ca5',1,'GameStartRule']]],
  ['subtlefontcolor_657',['subtleFontColor',['../GuiConstants_8hpp.html#a900b194179f7e103a3fafd2033bcdb11',1,'GuiConstants.hpp']]]
];

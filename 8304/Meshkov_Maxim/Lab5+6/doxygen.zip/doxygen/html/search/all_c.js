var searchData=
[
  ['needtoclose_219',['needToClose',['../classNewUnitSelectionScreen.html#aa6f78d80094260c706a36a6d49de4024',1,'NewUnitSelectionScreen::needToClose()'],['../classUnitInfoScreen.html#a84a9697245d2aaf0541cf4f47ecc8e49',1,'UnitInfoScreen::needToClose()']]],
  ['newgame_220',['newGame',['../classGui.html#a90ab0bfd104fc1a2d22ff5835b77fbc0',1,'Gui']]],
  ['newunitselectionscreen_221',['NewUnitSelectionScreen',['../classNewUnitSelectionScreen.html',1,'NewUnitSelectionScreen'],['../classNewUnitSelectionScreen.html#a76abfb705892ab7152182573494c91a2',1,'NewUnitSelectionScreen::NewUnitSelectionScreen()']]],
  ['newunitselectionscreen_2ecpp_222',['NewUnitSelectionScreen.cpp',['../NewUnitSelectionScreen_8cpp.html',1,'']]],
  ['newunitselectionscreen_2ehpp_223',['NewUnitSelectionScreen.hpp',['../NewUnitSelectionScreen_8hpp.html',1,'']]],
  ['normalfontcolor_224',['normalFontColor',['../GuiConstants_8hpp.html#adeed7822d2c9b65e757658e8158a6c74',1,'GuiConstants.hpp']]],
  ['normalfontsize_225',['normalFontSize',['../GuiConstants_8hpp.html#adbda50ff14a84d6cb6a01716352e571b',1,'GuiConstants.hpp']]],
  ['notifyaboutdeletionfromfield_226',['notifyAboutDeletionFromField',['../classBaseUnit.html#a42306bea7629efe3add648e118c180a3',1,'BaseUnit::notifyAboutDeletionFromField()'],['../classUnit.html#a5dbc056a4c0bfd5ad70e0d8314c7e949',1,'Unit::notifyAboutDeletionFromField()']]]
];

var searchData=
[
  ['_7egameproxywithfilelogging_576',['~GameProxyWithFileLogging',['../classGameProxyWithFileLogging.html#a1d0dbca1d7ce43eb6ae671fd339c2acf',1,'GameProxyWithFileLogging']]],
  ['_7eunit_577',['~Unit',['../classUnit.html#a33361af029acdb5177052f40e6d4b18f',1,'Unit']]]
];

var searchData=
[
  ['unittype_672',['UnitType',['../classGameMemento.html#aa90997cec8963890d7cf1442e9cf47c2',1,'GameMemento']]]
];
